export const MASTER_PORTFOLIO_DATA: { masterId: number; charmDirectLink: string }[] = [
  {
    masterId: 811339,
    charmDirectLink:
      'https://stage.charmdirect.ru/yc811339/collections/ZlNG2_cDYUnF8-DvXnrK6',
  },
];
