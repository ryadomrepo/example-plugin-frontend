import { initializePlugin } from './plugin';

initializePlugin();
